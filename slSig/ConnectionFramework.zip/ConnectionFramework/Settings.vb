﻿
Namespace My
    
    Partial NotInheritable Class MySettings

    End Class

End Namespace
