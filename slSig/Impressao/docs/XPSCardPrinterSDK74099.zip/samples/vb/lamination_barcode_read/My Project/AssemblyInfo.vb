﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("Lamination Barcode Read")> 
<Assembly: AssemblyDescription("XPS Driver SDK Barcode Read Lamination Sample")> 
<Assembly: AssemblyCompany("Datacard")> 
<Assembly: AssemblyProduct("XPS Driver SDK Lamination Barcode Read Sample")> 
<Assembly: AssemblyCopyright("Copyright © Datacard")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")>