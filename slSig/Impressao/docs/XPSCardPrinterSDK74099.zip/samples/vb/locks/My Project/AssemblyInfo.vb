﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("locks")> 
<Assembly: AssemblyDescription("XPS Driver SDK vb.net Locks sample")> 
<Assembly: AssemblyCompany("Datacard")> 
<Assembly: AssemblyProduct("locks sdk sample")> 
<Assembly: AssemblyCopyright("Copyright © Datacard")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
