﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("emboss_indent")> 
<Assembly: AssemblyDescription("XPS Driver SDK vb.net emboss indent sample")> 
<Assembly: AssemblyCompany("Datacard")> 
<Assembly: AssemblyProduct("emboss_indent sdk sample")> 
<Assembly: AssemblyCopyright("Copyright © Datacard")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
