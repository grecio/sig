#pragma once

#include "targetver.h"
#include <atlbase.h>
#include <atlstr.h>
#include <winnt.h>
