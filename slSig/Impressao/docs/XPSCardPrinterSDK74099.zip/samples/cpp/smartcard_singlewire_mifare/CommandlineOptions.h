#pragma once

struct CommandlineOptions {
    CString printerName;
    bool print {false};
    bool cardCompletion {false};
    bool parkBack {false};
};