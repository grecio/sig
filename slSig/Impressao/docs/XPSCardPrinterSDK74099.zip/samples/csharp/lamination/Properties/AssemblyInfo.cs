﻿////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Datacard Corporation.  All Rights Reserved.
////////////////////////////////////////////////////////////////////////////////
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Datacard")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Datacard")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("XPS Driver SDK lamination sample")]
[assembly: AssemblyTitle("XPS Driver SDK lamination sample")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: ComVisible(false)]