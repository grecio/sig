﻿////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Datacard Corporation.  All Rights Reserved.
////////////////////////////////////////////////////////////////////////////////
using System.Reflection;

[assembly: AssemblyCompany("Datacard")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Datacard")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("locks")]
[assembly: AssemblyTitle("locks")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]