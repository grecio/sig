﻿////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Datacard Corporation.  All Rights Reserved.
//
////////////////////////////////////////////////////////////////////////////////
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("smartcard")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Datacard")]
[assembly: AssemblyProduct("smartcard")]
[assembly: AssemblyCopyright("Copyright © Datacard")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]